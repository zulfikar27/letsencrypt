Compatibility tests for Certbot
