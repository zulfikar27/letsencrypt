.. certbot-dns-cloudxns documentation master file, created by
   sphinx-quickstart on Wed May 10 16:05:50 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to certbot-dns-cloudxns's documentation!
================================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: certbot_dns_cloudxns
   :members:

.. toctree::
   :maxdepth: 1

   api



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
